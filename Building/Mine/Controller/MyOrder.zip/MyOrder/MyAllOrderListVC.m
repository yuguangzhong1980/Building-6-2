//
//  MyAllOrderListVC.m
//  Building
//
//  Created by Macbook Pro on 2019/2/28.
//  Copyright © 2019 Macbook Pro. All rights reserved.
//

#import "MyAllOrderListVC.h"
#import "MyYuYueCell.h"

#define MyYuYueCellHeight       160
#define MyYuYueCellXibName       @"MyYuYueCell"

@interface MyAllOrderListVC ()<UITableViewDataSource, UITableViewDelegate>
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (nonatomic, strong) NSMutableArray *datasourceArr;
@end

@implementation MyAllOrderListVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.datasourceArr = @[@"1", @"2"].mutableCopy;
    
    self.tableView.tableFooterView = [[UIView alloc] init];
}

#pragma mark - UITableView Delegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [self.datasourceArr count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    //再写个cell，不要用MyYuYueCell这个cell，这个cell是我的预约功能用的，这是为了编译过，临事用用
    MyYuYueCell *cell = (MyYuYueCell *)[self getCellFromXibName:MyYuYueCellXibName dequeueTableView:tableView];
    NSString *model = self.datasourceArr[indexPath.row];
    cell.textLabel.text = model;
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return MyYuYueCellHeight;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    NSInteger row = [indexPath row];
    
}

@end
